COMMENTS CONCERNING THE ALGORITHM

The following modifications have to be made:
1.) The name and the directoriy of the inputfile and the name of the outputfile (line 43 and line 44)
    Actually they are defined as
    inputfilename = "F:\\_TGIS_ascending_and_descending_manifolds\\Example_critical_net.txt" 
    and
    outputfilename = "F:\\_TGIS_ascending_and_descending_manifolds\\Example_results.txt" must be modified.
2.) The number of the point whose ascending/descending manifold shoud be determined (line 195)
    For the actual data set the numbers 
    17 - 20 (local mininma)
    and
    34-43 (local maxima)
    are valid
