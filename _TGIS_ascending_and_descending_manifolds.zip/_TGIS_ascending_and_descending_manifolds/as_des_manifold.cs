﻿using Microsoft.VisualBasic;
using System;
using System.ComponentModel.Design;
using System.IO;
using System.Net.NetworkInformation;
using System.Reflection.Metadata;
using System.Xml;
using System.Xml.Linq;

namespace Manifolds
{
    class Ascending_Descending_manifolds
    {
        public static void Main()
        {
            // definition of variables
            int ifail = 0, m1 = 0, m2 = 0, m3 = 0, number_of_slms_edges = 0;
            int boundary_length = 0, pos = 0;
            int critical_point, virtual_pit;
            int[] local_minimum = new int[500];
            int[] local_maximum = new int[500];
            int[] saddle = new int[500];
            int[,] saddle_left = new int[500, 2];
            int[,] saddle_right = new int[500, 2];
            int[,] slms_edges = new int[500, 3];
            int[] boundary = new int[1000];
            string inputfilename, outputfilename;
            string? text;
            string[] type = new string[2];

            // definition of dummy variables
            int i, j, k;
            int saddle_0, saddle_left_1, saddle_left_2;
            int saddle_right_1, saddle_right_2;
            int[] dummy_int_1 = new int[1000];
            int[] dummy_int_2 = new int[1000];
            int[] dummy_int_3 = new int[1000];
            int[] dummy_int_4 = new int[1000];
            bool[] dummy_bool_1 = new bool[1000];
            bool[] dummy_bool_2 = new bool[1000];

            // specification of the input file and output file
            inputfilename = "F:\\_TGIS_ascending_and_descending_manifolds\\Example_critical_net.txt";
            outputfilename = "F:\\_TGIS_ascending_and_descending_manifolds\\Example_results.txt";

            if (!File.Exists(inputfilename))
            {
                // error due to a wrong name of the input file
                StreamWriter outputfile = new(outputfilename);
                outputfile.WriteLine("Inputfile cannot be opened!");
                outputfile.Close();
            }
            else
            {
                StreamReader inputfile = new(inputfilename);
                StreamWriter outputfile = new(outputfilename);

                // specification of the local minimum that is associated with the virtual pit
                virtual_pit = 1;

                // the input data are read from the input file

                // the comment lines are read (lines before the keyword "CRITICAL NET")
                while ((text = inputfile.ReadLine()) != "CRITICAL NET") text = inputfile.ReadLine();

                // the critical net is read (lines before the keyword "SLMS-EDGES")
                text = inputfile.ReadLine();
                while ((text = inputfile.ReadLine()) != "SLMS-EDGES")
                {
                    saddle_0 = Int32.Parse(text.Substring(0, 10));
                    saddle_left_1 = Int32.Parse(text.Substring(10, 10));
                    saddle_left_2 = Int32.Parse(text.Substring(20, 10));
                    saddle_right_1 = Int32.Parse(text.Substring(30, 10));
                    saddle_right_2 = Int32.Parse(text.Substring(40, 10));

                    // the following two lines perform the one-point compactification
                    if (saddle_left_1 <= 16) saddle_left_1 = virtual_pit;
                    if (saddle_left_2 <= 16) saddle_left_2 = virtual_pit;

                    // the arrays containing the names of the local minima and local maxima of the
                    // critical net are built, with the elements being sorted in ascenting order
                    if (ifail == 0) Insert(ref local_minimum, ref m1, ref saddle_left_1, ref ifail);
                    if (ifail == 0) Insert(ref local_minimum, ref m1, ref saddle_left_2, ref ifail);
                    if (ifail == 0) Insert(ref local_maximum, ref m3, ref saddle_right_1, ref ifail);
                    if (ifail == 0) Insert(ref local_maximum, ref m3, ref saddle_right_2, ref ifail);

                    // the arrays containing the names of the saddle points as well as of the local
                    // minima and local maximia being adjacent to them are built, with the names
                    // of the saddle points being arranged in ascending order; 'saddle_left'
                    // corresponds to the subgraph [LMIN,SADD], 'saddle_right' corresponds to
                    // the subgraph [SADD,LMAX]
                    if (ifail == 0) Insert(ref saddle, ref m2, ref saddle_0, ref ifail);
                    if (ifail == 0) Bin_Search(saddle, m2, saddle_0, ref pos, ref ifail);
                    for (i = m2 - 1; i >= pos; i--)
                    {
                        saddle_left[i + 1, 0] = saddle_left[i, 0];
                        saddle_left[i + 1, 1] = saddle_left[i, 1];
                        saddle_right[i + 1, 0] = saddle_right[i, 0];
                        saddle_right[i + 1, 1] = saddle_right[i, 1];
                    }
                    saddle_left[pos, 0] = saddle_left_1;
                    saddle_left[pos, 1] = saddle_left_2;
                    saddle_right[pos, 0] = saddle_right_1;
                    saddle_right[pos, 1] = saddle_right_2;
                }

                // the array containing the slms-edges, which provide information related to
                // circuits of length two, is built on condition that there exist such edges
                // (lines before EOF occurs)
                text = inputfile.ReadLine();
                while ((text = inputfile.ReadLine()) != null)                   
                {
                    slms_edges[number_of_slms_edges, 0] = Int32.Parse(text.Substring(0, 10));
                    slms_edges[number_of_slms_edges, 1] = Int32.Parse(text.Substring(10, 10));
                    
                    // the following line performs the one-point compactification for the
                    // slms-edges
                    if (slms_edges[number_of_slms_edges, 1] <= 16) slms_edges[number_of_slms_edges, 1] = virtual_pit;
                    
                    slms_edges[number_of_slms_edges, 2] = Int32.Parse(text.Substring(20, 10));
                    number_of_slms_edges++;
                }
                inputfile.Close();

                // output of input data
                outputfile.WriteLine("                      *********************************************");
                outputfile.WriteLine("                      *                                           *");
                outputfile.WriteLine("                      *      ASCENDING / DESCENDING MANIFOLD      *");
                outputfile.WriteLine("                      *                                           *");
                outputfile.WriteLine("                      *********************************************");
                outputfile.WriteLine();
                outputfile.WriteLine("     CRITICAL NET");
                outputfile.WriteLine("     ************");
                outputfile.WriteLine();
                outputfile.Write("     NUMBER OF LOCAL MINIMA      ");
                outputfile.WriteLine(String.Format("{0,5}", m1));
                outputfile.Write("     NUMBER OF SADDLE POINTS     ");
                outputfile.WriteLine(String.Format("{0,5}", m2));
                outputfile.Write("     NUMBER OF LOCAL MAXIMA      ");
                outputfile.WriteLine(String.Format("{0,5}", m3));
                outputfile.WriteLine();
                outputfile.Write("     LOCAL MINIMA   ");
                for (i = 0; i <= m1 - 1; i += 10)
                {
                    j = Math.Min(m1 - i, 10);
                    if (i != 0) outputfile.Write("                    ");
                    for (k = i; k < i + j; k++) outputfile.Write(String.Format("{0,6}", local_minimum[k]));
                    outputfile.WriteLine();
                }
                outputfile.WriteLine();
                outputfile.Write("     SADDLE POINTS  ");
                for (i = 0; i <= m2 - 1; i += 10)
                {
                    j = Math.Min(m2 - i, 10);
                    if (i != 0) outputfile.Write("                    ");
                    for (k = i; k < i + j; k++) outputfile.Write(String.Format("{0,6}", saddle[k]));
                    outputfile.WriteLine();
                }
                outputfile.WriteLine();
                outputfile.Write("     LOCAL MAXIMA   ");
                for (i = 0; i <= m3 - 1; i += 10)
                {
                    j = Math.Min(m3 - i, 10);
                    if (i != 0) outputfile.Write("                    ");
                    for (k = i; k < i + j; k++) outputfile.Write(String.Format("{0,6}", local_maximum[k]));
                    outputfile.WriteLine();
                }
                outputfile.WriteLine();
                outputfile.WriteLine("          SADDLE     1.LOCAL MIN     2.LOCAL MIN     1.LOCAL MAX     2.LOCAL MAX");
                for (i = 0; i <= m2 - 1; i++)
                {
                    outputfile.Write(String.Format("{0,16}", saddle[i]));
                    outputfile.Write(String.Format("{0,16}", saddle_left[i, 0]));
                    outputfile.Write(String.Format("{0,16}", saddle_left[i, 1]));
                    outputfile.Write(String.Format("{0,16}", saddle_right[i, 0]));
                    outputfile.WriteLine(String.Format("{0,16}", saddle_right[i, 1]));
                }
                if (number_of_slms_edges > 0)
                {
                    outputfile.WriteLine();
                    outputfile.WriteLine("     SLMS-EDGES");
                    outputfile.WriteLine("     **********");

                    outputfile.WriteLine("          SADDLE   LOCAL MIN/MAX          SADDLE");
                    for (i = 0; i <= number_of_slms_edges - 1; i++)
                    {
                        outputfile.Write(String.Format("{0,16}", slms_edges[i, 0]));
                        outputfile.Write(String.Format("{0,16}", slms_edges[i, 1]));
                        outputfile.WriteLine(String.Format("{0,16}", slms_edges[i, 2]));
                    }
                }

                // specification of the critical point from which the manifold's boundary must
                // be determined
                critical_point = 19;

                // check whether an error due to the input data exists
                if (ifail == 0)
                {
                    // check if the critical point is a local minimum
                    Bin_Search(local_minimum, m1, critical_point, ref pos, ref ifail);
                    if (ifail == 0)
                    {
                        // the critical point is a local minimum and the boundary of its
                        // ascending manifold is determined
                        Manifold_Ascending(m1, m2, m3, local_minimum, saddle, local_maximum,
                        saddle_left, saddle_right, critical_point, virtual_pit, ref slms_edges,
                        number_of_slms_edges, ref boundary, ref boundary_length, ref ifail,
                        ref dummy_int_1, ref dummy_int_2, ref dummy_int_3, ref dummy_int_4,
                        ref dummy_bool_1, ref dummy_bool_2);

                        for (i = 0; i < 2; i++) outputfile.WriteLine();
                        outputfile.Write("     BOUNDARY OF THE ASCENDING MANIFOLD OF THE LOCAL MINIMUM");
                        outputfile.WriteLine(String.Format("{0,4}", critical_point));
                        outputfile.WriteLine("     ***********************************************************");

                        // check if the boundary starts with a saddle point or a local maximum
                        Bin_Search(saddle, m2, boundary[0], ref pos, ref ifail);
                        if (ifail == 0)
                        {
                            type[0] = "     Saddle            ";
                            type[1] = "     Local maximum     ";
                        }
                        else
                        {
                            type[0] = "     Local maximum     ";
                            type[1] = "     Saddle            ";
                        }
                        for (i = 0; i <= boundary_length; i++)
                        {
                            if ((i % 2) == 0)
                            {
                                outputfile.Write(type[0]);
                                outputfile.WriteLine(String.Format("{0,8}", boundary[i]));
                            }
                            else
                            {
                                outputfile.Write(type[1]);
                                outputfile.WriteLine(String.Format("{0,8}", boundary[i]));
                            }
                        }
                    }
                    else
                    {
                        // check if the critical point is a local maximum
                        Bin_Search(local_maximum, m3, critical_point, ref pos, ref ifail);
                        if (ifail == 0)
                        {
                            // the critical point is a local maximum and the boundary of its
                            // descending manifold is determined
                            Manifold_Descending(m1, m2, m3, local_minimum, saddle, local_maximum,
                            saddle_left, saddle_right, critical_point, virtual_pit, ref slms_edges,
                            number_of_slms_edges, ref boundary, ref boundary_length, ref ifail,
                            ref dummy_int_1, ref dummy_int_2, ref dummy_int_3, ref dummy_int_4,
                            ref dummy_bool_1, ref dummy_bool_2);

                            for (i = 0; i < 2; i++) outputfile.WriteLine();
                            outputfile.Write("     BOUNDARY OF THE DESCENDING MANIFOLD OF THE LOCAL MAXIMUM");
                            outputfile.WriteLine(String.Format("{0,4}", critical_point));
                            outputfile.WriteLine("     ************************************************************");

                            // check if the boundary starts with a saddle point or a local minimum
                            Bin_Search(saddle, m2, boundary[0], ref pos, ref ifail);
                            if (ifail == 0)
                            {
                                type[0] = "     Saddle            ";
                                type[1] = "     Local minimum     ";
                            }
                            else
                            {
                                type[0] = "     Local minimum     ";
                                type[1] = "     Saddle            ";
                            }
                            for (i = 0; i <= boundary_length; i++)
                            {
                                if ((i % 2) == 0)
                                {
                                    outputfile.Write(type[0]);
                                    outputfile.WriteLine(String.Format("{0,8}", boundary[i]));
                                }
                                else
                                {
                                    outputfile.Write(type[1]);
                                    outputfile.WriteLine(String.Format("{0,8}", boundary[i]));
                                }
                            }
                        }
                    }
                }
                outputfile.Close();
            }
        }


        private static void Bin_Search(int[] array, int n, int element, ref int position, ref int errorcode)
        {
            // Parameters
            // array....................array whose elements must be differnt from each other and
            //                          have to be sorted in ascending order
            // n........................number of elements of the array
            // element..................element whose position has to be determined
            // position.................position of the element
            // errorcode................specifies the type of error
            //
            // Errorcode
            // 0. If errorcode = 0, no error was detected
            // 1. If errorcode = 1, n <= 0 was chosen
            // 2. If errorcode = 2, the elements of the array are not sorted in ascending order
            //                      or they are not different from each other
            // 3. If errorcode = 3, the element was not found in the array; in this case
            //                      'position' is set to -1
            //
            // Remarks
            // 1. The procedure determines the position of an element in an array whose elements
            //    must be different from each other and have to be sorted in ascending order.
            // 2. No other procedures are called.

            bool found = false;
            int i = 0;
            int lower, middle, upper;

            // check for possible input errors
            errorcode = 0;
            if (n <= 0) errorcode = 1;

            if (n > 1)
            {
                while (errorcode == 0 && i <= n - 2)
                {
                    if (array[i + 1] <= array[i]) errorcode = 2;
                    i++;
                }
            }

            // no error was detected and the position of the element is determined
            if (errorcode == 0)
            {

                // the array contains only one element
                if (n == 1)
                {
                    if (array[0] == element)
                    {
                        position = 0;
                        found = true;
                    }
                }

                // the array contains exactly two elements
                if (n == 2)
                {
                    if (array[0] == element)
                    {
                        position = 0;
                        found = true;
                    }
                    else
                    {
                        if (array[1] == element)
                        {
                            position = 1;
                            found = true;
                        }
                    }
                }

                // the array contains more than two elements
                if (n > 2)
                {
                    lower = 0;
                    upper = n - 1;
                    while (upper - lower > 1)
                    {
                        middle = (lower + upper) / 2;
                        if (array[middle] <= element)
                        {
                            lower = middle;
                        }
                        else
                        {
                            upper = middle;
                        }
                        if (array[lower] == element)
                        {
                            position = lower;
                            found = true;
                        }
                        else
                        {
                            if (array[upper] == element)
                            {
                                position = upper;
                                found = true;
                            }
                        }
                    }
                }
                // the element was not found in the array
                if (!found)
                {
                    position = -1;
                    errorcode = 3;
                }
            }
        }


        private static void Insert(ref int[] array, ref int n, ref int element, ref int errorcode)
        {
            // Parameters
            // array....................array in which an element has to be inserted; the elements
            //                          of the array must be different from each other and have
            //                          to be sorted in ascending order
            // n........................number of elements of the array
            // element..................element that has to be inserted
            // errorcode................specifies the type of error
            //
            // Errorcode
            // 0. If errorcode = 0, no error was detected
            // 1. If errorcode = 1, n < 0 was chosen
            // 2. If errorcode = 2, the elements of the array are not sorted in ascending order
            //                      or they are not different from each other
            //
            // Remarks
            // 1. The procedure inserts an element into an array, whose elements must be different
            //    from each other and have to be sorted in ascending order, provided the element
            //    does not already occur in the array; in addition, the procedure modifies the
            //    number of elements of the array accordingly.
            // 2. After the insertion process the elements of the array are sorted in ascending
            //    order, too.
            // 3. No other procedures are called.

            int i, lower, middle, upper;
            bool inserted = false;

            // check for possible input errors in combination with a check whether the element
            // to be inserted already exists in the array
            errorcode = 0;

            if (n < 0) errorcode = 1;

            i = 0;
            if (n > 1)
            {
                while (errorcode == 0 && i <= n - 2)
                {
                    if (array[i + 1] <= array[i]) errorcode = 2;
                    if (array[i] == element) inserted = true;
                    i++;
                }
                if (array[n - 1] == element) inserted = true;
            }

            // no error was detected and the new element is inserted into the array
            if (errorcode == 0 && !inserted)
            {
                if (n == 0)
                {
                    // the array is empty and the new element is the first one in the array
                    array[0] = element;
                    n++;
                }
                else
                {
                    if (n == 1 && array[0] != element)
                    {
                        // the array contains only one element which is different from
                        // the new element
                        if (array[0] < element)
                        {
                            array[1] = element;
                        }
                        else
                        {
                            array[1] = array[0];
                            array[0] = element;
                        }
                        n++;
                    }
                    else
                    {
                        if (n > 1)
                        {
                            // the array contains more than one element
                            if (array[n - 1] < element)
                            {
                                // the new element will be the last one in the array
                                array[n] = element;
                                n++;
                            }
                            else
                            {
                                if (array[0] > element)
                                {
                                    // the new element will be the first one in the array
                                    for (i = n - 1; i >= 0; i--) array[i + 1] = array[i];
                                    array[0] = element;
                                    n++;
                                }
                                else
                                {
                                    // the new element will be inserted somewhere in the array
                                    // with the position being determined by binary search
                                    lower = 0;
                                    upper = n - 1;
                                    while (n == 2 || (upper - lower > 1))
                                    {
                                        middle = (lower + upper) / 2;
                                        if (array[middle] <= element)
                                        {
                                            lower = middle;
                                        }
                                        else
                                        {
                                            upper = middle;
                                        }
                                        if (array[lower] < element && array[lower + 1] > element)
                                        {
                                            for (i = n - 1; i >= lower + 1; i--) array[i + 1] = array[i];
                                            array[lower + 1] = element;
                                            n++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }

        private static void Manifold_Ascending(int m1, int m2, int m3, int[] local_mininimum,
        int[] saddle, int[] local_maximum, int[,] saddle_left, int[,] saddle_right, int lmin,
        int virtual_pit, ref int[,] slms_edges, int number_of_slms_edges, ref int[] boundary,
        ref int boundary_length, ref int errorcode, ref int[] subgraph, ref int[] subgraph_pointer,
        ref int[] subgraph_index, ref int[] slms_edge_index, ref bool[] slms_edge_per_vertex,
        ref bool[] reached)
        {
            // Parameters
            // m1.......................number of local minima of the critical net
            // m2.......................number of saddle points of the critical net
            // m3.......................number of local maxima of the critical net
            // local_minimum............array storing the names of the local minima; the array
            //                          must be sorted in ascending order
            // saddle...................array storing the names of the saddle points; the array
            //                          must be sorted in ascending order
            // local_maximum............array storing the names of the local maxima; the array
            //                          must be sorted in ascending order
            // saddle_left..............array in which the names of the adjacent local minima
            //                          of the saddle points are stored; it corresponds
            //                          to the subgraph [LMIN,SADD]
            // saddle_right.............array in which the names of the adjacent local maxima
            //                          of the saddle points are stored; it corresponds
            //                          to the subgraph [SADD,LMAX]
            // lmin.....................name of the local minimum from which the boundary of
            //                          the ascending manifold A(lmin) must be determined
            // virtual_pit..............name of the local minimum associated with the virtual pit
            // slms_edges...............array storing the slms-edges
            // number_of_slms_edges ....number of slms-edges
            // boundary.................array storing the names of the critical points that
            //                          form the boundary of A(lmin); the first and the last
            //                          element of the array 'boundary' are identical as the
            //                          boundary is closed
            // boundary_length..........number of elements of the array 'boundary'
            // errorcode................specifies the type of error
            // subgraph.................array storing the names of the saddle points and
            //                          local minima which form the boundary of A(lmin); the
            //                          differene to the array 'boundary' is the order in which
            //                          the elements occur
            // subgraph_pointer.........array required for the representation of the subgraph
            //                          by a pointer structure
            // subgraph_index...........array required for the representation of the subgraph  
            //                          by a pointer structure
            // slms_edge_index..........array required for the representation of the slms-edges
            //                          by a pointer structure
            // slms_edge_per_vertex.....array indicating if a specific vertex of the subgraph has
            //                          incident slms-edges
            // reached..................array indicating if a specific vertex of the subgraph has
            //                          aleady been added to the array 'boundary'
            // The (maximal) dimensions of the arrays are as follows:
            // local_minimum[m1], saddle[m2], local_maximum[m3], saddle_left[m2, 2], saddle_right[m2, 2],
            // slms-edges[number_of_slms_edges, 3], boundary[m2 + m3  + 1], subgraph[m2 + m3],
            // subgraph_pointer[m2 + m3 + 1], subgraph_index[2 * (m2 + m3)], slms_edge_index[2 * (m2 + m3)],
            // slms_edge_per_vertex[m2 + m3], reached[m2 + m3]
            // 
            // Errorcode
            // 0. If errorcode = 0, no error was detected
            // 1. If errorcode = 1, m1 < 1 or m2 < 1 or m3 <1 or m1 - m2 + m3 <> 2 was chosen
            // 2. If errorcode = 2, a local minimum was also declared as saddle point or vice versa
            // 3. If errorcode = 3, a local minimum was also declared as local maximum or vice versa
            // 4. If errorcode = 4, a saddle point was also declared as local maximum or vice versa
            // 5. If errorcode = 5, the array 'local_minimum' is not sorted in ascending order
            // 6. If errorcode = 6, the array 'saddle' is not sorted in ascending order
            // 7. If errorcode = 7, the array 'local_maximum' is not sorted in ascending order
            // 8. If errorcode = 8, 'lmin' is not an element of the array 'local_maximum'
            // 9. If errorcode = 9, 'virtual_pit' is not an element of the array 'local_minimum'
            //
            // Remarks
            // 1. The procedure determines the boundary of the ascending manifold A(lmin) of the
            //    local minimum 'lmin'. 
            // 2. The region must be surrounded by a virtual pit.
            // 3. The topology of the region must be represented by a critical net.
            // 4. The following two procedures are called:
            //    'Bin_Search' - it determines the position of an element in an array whose
            //                   elements must be different from each other and have to be
            //                   sorted in ascending order.
            //    'Insert'     - it inserts an element into an array, whose elements must
            //                   be different from each other and have to be sorted in
            //                   ascending order, provided the element does not already
            //                   occur in the array; in addition, the procedure modifies the
            //                   number of elements of the array accordingly.

           int i, j, k, l, ifail = 0, ifail_1 = 0, ifail_2 = 0, ifail_3 = 0, pos = 0, pos_0 = 0, pos_1 = 0;
            int circuit_number = 0, new_circuit_number = 0;
            int final_vertex = 0, subgraph_number_of_vertices = 0, vertex, vertex_new = 0;
            bool found_1, found_2, relevant_slms_edge;

            // check for possible input errors
            errorcode = 0;

            if (m1 < 1 || m2 < 1 || m3 < 1 || (m1 - m2 + m3 != 2)) errorcode = 1;

            i = 0;
            while (errorcode == 0 && i <= m1 - 1)
            {
                j = 0;
                while (errorcode == 0 && j <= m2 - 1)
                {
                    if (local_mininimum[i] == saddle[j]) errorcode = 2;
                    j++;
                }
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m1 - 1)
            {
                j = 0;
                while (errorcode == 0 && j <= m3 - 1)
                {
                    if (local_mininimum[i] == local_maximum[j]) errorcode = 3;
                    j++;
                }
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m2 - 1)
            {
                j = 0;
                while (errorcode == 0 && j <= m3 - 1)
                {
                    if (saddle[i] == local_maximum[j]) errorcode = 4;
                    j++;
                }
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m1 - 2)
            {
                if (local_mininimum[i + 1] <= local_mininimum[i]) errorcode = 5;
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m2 - 2)
            {
                if (saddle[i + 1] <= saddle[i]) errorcode = 6;
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m3 - 2)
            {
                if (local_maximum[i + 1] <= local_maximum[i]) errorcode = 7;
                i++;
            }

            if (errorcode == 0)
            {
                Bin_Search(local_mininimum, m1, lmin, ref pos, ref errorcode);
                if (errorcode > 0) errorcode = 8;
                if (errorcode == 0)
                {
                    Bin_Search(local_mininimum, m1, virtual_pit, ref pos, ref errorcode);
                    if (errorcode > 0) errorcode = 9;
                    if (errorcode == 0)
                    {
                        if (lmin == virtual_pit) errorcode = 10;
                    }
                }
            }

            // no error was detected and the boundary of A(lmin) is determined
            if (errorcode == 0)
            {
                // extraction of the subgraph that contains the boundary of the descending
                // manifold A(lmin), with the result being stored by a pointer structure

                // step one:
                // the array 'subgraph' that contains the names of the saddle points and local
                // minima that form the boundary is built, whereby the elements of the array
                // are sorted in ascending order
                // 'subgraph_number_of_vertices' specifies the number of vertices within the
                // subgraph
                for (i = 0; i <= m2 - 1; i++)
                {
                    if (saddle_left[i, 0] == lmin || saddle_left[i, 1] == lmin)
                    {
                        Insert(ref subgraph, ref subgraph_number_of_vertices, ref saddle[i], ref ifail);
                        Insert(ref subgraph, ref subgraph_number_of_vertices, ref saddle_right[i, 0], ref ifail);
                        Insert(ref subgraph, ref subgraph_number_of_vertices, ref saddle_right[i, 1], ref ifail);
                    }
                }

                // step two:
                // the subgraph is extracted from the array 'saddle_right' and transformed into
                // its undirected form, whereby the result is stored by a pointer structure

                // the array 'subgraph_pointer' is used to identify the sections, in which the
                // adjacent critical points of a vertex are stored 
                // the array 'subgraph_index' specifies the indices of the adjacent vertices
                // as they occur in the array 'subgraph' (all calculations are performed on
                // basis of the array 'subgraph_index')


                // initialisation of the array 'subgraph_pointer'
                for (i = 0; i <= subgraph_number_of_vertices; i++) subgraph_pointer[i] = 0;

                // the pointer structure of the subgraph is built by scanning the saddle
                // points and determining the adjacent local minima
                j = -1;
                for (i = 0; i <= subgraph_number_of_vertices - 1; i++)
                {
                    Bin_Search(saddle, m2, subgraph[i], ref pos, ref ifail);
                    if (ifail == 0)
                    {
                        Bin_Search(subgraph, subgraph_number_of_vertices, saddle_right[pos, 0], ref pos_0, ref ifail);
                        Bin_Search(subgraph, subgraph_number_of_vertices, saddle_right[pos, 1], ref pos_1, ref ifail);

                        // the adjacency relationships of the saddle point are modified
                        j = j + 2;
                        for (k = i + 1; k <= subgraph_number_of_vertices; k++) subgraph_pointer[k] = subgraph_pointer[k] + 2;
                        for (k = j - 1; k >= subgraph_pointer[i]; k--) subgraph_index[k + 2] = subgraph_index[k];
                        subgraph_index[subgraph_pointer[i]] = pos_0;
                        subgraph_index[subgraph_pointer[i] + 1] = pos_1;

                        // the adjacency relationship of the first local minimum is modified
                        j++;
                        for (k = pos_0 + 1; k <= subgraph_number_of_vertices; k++) subgraph_pointer[k] = subgraph_pointer[k] + 1;
                        for (k = j - 1; k >= subgraph_pointer[pos_0]; k--) subgraph_index[k + 1] = subgraph_index[k];
                        subgraph_index[subgraph_pointer[pos_0]] = i;

                        // the adjacency relationship of the second local minimum is modified
                        j++;
                        for (k = pos_1 + 1; k <= subgraph_number_of_vertices; k++) subgraph_pointer[k] = subgraph_pointer[k] + 1;
                        for (k = j - 1; k >= subgraph_pointer[pos_1]; k--) subgraph_index[k + 1] = subgraph_index[k];
                        subgraph_index[subgraph_pointer[pos_1]] = i;
                    }
                }

                // if slms_edges exist, they are stored in the array 'slms_edge_index', which is built next
                if (number_of_slms_edges > 0)
                {
                    // initialisation of the array 'slms_edge_index'
                    for (i = 0; i <= subgraph_pointer[subgraph_number_of_vertices + 1] - 1; i++) slms_edge_index[i] = 0;

                    for (i = 0; i <= number_of_slms_edges - 1; i++)
                    {
                        Bin_Search(subgraph, subgraph_number_of_vertices, slms_edges[i, 0], ref pos, ref ifail_1);
                        Bin_Search(subgraph, subgraph_number_of_vertices, slms_edges[i, 1], ref pos_0, ref ifail_2);
                        Bin_Search(subgraph, subgraph_number_of_vertices, slms_edges[i, 2], ref pos_1, ref ifail_3);
                        if (ifail_1 == 0 && ifail_2 == 0 && ifail_3 == 0)
                        {
                            // an slms_edge was detected - the first edge is processed
                            found_1 = false;
                            for (j = subgraph_pointer[pos]; j <= subgraph_pointer[pos + 1] - 1; j++)
                            {
                                if (subgraph_index[j] == pos_0 && slms_edge_index[j] == 0 && found_1 == false)
                                {
                                    slms_edge_index[j] = i + 1;
                                    found_1 = true;
                                    found_2 = false;
                                    for (k = subgraph_pointer[pos_0]; k <= subgraph_pointer[pos_0 + 1] - 1; k++)
                                    {
                                        if (subgraph_index[k] == pos && slms_edge_index[k] == 0 && found_2 == false)
                                        {
                                            slms_edge_index[k] = i + 1;
                                            found_2 = true;
                                        }
                                    }
                                }
                            }

                            // an slms_edge was detected - the second edge is processed
                            found_1 = false;
                            for (j = subgraph_pointer[pos_0]; j <= subgraph_pointer[pos_0 + 1] - 1; j++)
                            {
                                if (subgraph_index[j] == pos_1 && slms_edge_index[j] == 0 && found_1 == false)
                                {
                                    slms_edge_index[j] = i + 1;
                                    found_1 = true;
                                    found_2 = false;
                                    for (k = subgraph_pointer[pos_1]; k <= subgraph_pointer[pos_1 + 1] - 1; k++)
                                    {
                                        if (subgraph_index[k] == pos_0 && slms_edge_index[k] == 0 && found_2 == false)
                                        {
                                            slms_edge_index[k] = i + 1;
                                            found_2 = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // the vertices with incident slms_edges are tagged, with the information being
                // stored in the array 'slms_edge_per_vertex'

                // initialisation of the array 'slms_edge_per_vertex'
                for (i = 0; i <= subgraph_number_of_vertices - 1; i++) slms_edge_per_vertex[i] = false;

                for (i = 0; i <= subgraph_number_of_vertices - 1; i++)
                {
                    found_1 = false;
                    j = subgraph_pointer[i];
                    while (j <= subgraph_pointer[i + 1] - 1 && found_1 == false)
                    {
                        if (slms_edge_index[j] > 0)
                        {
                            found_1 = true;
                        }
                        else
                        {
                            j++;
                        }
                    }
                    if (found_1 == true)
                    {
                        slms_edge_per_vertex[i] = true;
                    }
                }

                // if slms-edges, which have to be considered when constructing A(lmin) exist,
                // this information is stored in 'relevant_slms_edge'
                relevant_slms_edge = false;
                i = 0;
                while (i <= subgraph_number_of_vertices - 1 && relevant_slms_edge == false)
                {
                    if (slms_edge_per_vertex[i] == true)
                    {
                        relevant_slms_edge = true;
                    }
                    else
                    {
                        i++;
                    }
                }

                // the circuit corresponding to the boundary of A(lmin) is determined

                // the array 'reached' stores information if a particular vertex of
                // the subgraph has already been added to the boundary or not

                // initialisation of the array 'reached'
                for (i = 0; i <= subgraph_number_of_vertices - 1; i++) reached[i] = false;

                if (relevant_slms_edge == false)
                {
                    // there exist no slms_edges in the subgraph
                    reached[0] = true;
                    i = 0;
                    vertex = 0;
                    boundary[0] = 0;
                    while (reached[subgraph_index[1]] == false)
                    {
                        reached[vertex] = true;
                        if (reached[subgraph_index[subgraph_pointer[vertex]]] == false)
                        {
                            boundary[i + 1] = subgraph_index[subgraph_pointer[vertex]];
                            vertex = subgraph_index[subgraph_pointer[vertex]];
                        }
                        else
                        {
                            if (reached[subgraph_index[subgraph_pointer[vertex] + 1]] == false)
                            {
                                boundary[i + 1] = subgraph_index[subgraph_pointer[vertex] + 1];
                                vertex = subgraph_index[subgraph_pointer[vertex] + 1];
                            }
                        }
                        i++;
                    }
                    boundary_length = i;
                }
                else
                {
                    // the subgraph consists of only two vertices, with the edges forming
                    // a circuit
                    if (subgraph_number_of_vertices == 2)
                    {
                        boundary[0] = 0;
                        boundary[1] = 1;
                        boundary[2] = 0;
                        boundary_length = 2;
                    }
                    else
                    // there exists at least one slms_edge in the subgraph
                    {
                        // it is ensured that the boundary always starts in a vertex
                        // with no incident slms-edges
                        vertex = 0;
                        found_1 = false;
                        while (found_1 == false)
                        {
                            if (slms_edge_per_vertex[vertex] == true)
                            {
                                vertex++;
                            }
                            else
                            {
                                found_1 = true;
                            }
                        }

                        // initialisation steps for the determination of the boundary
                        reached[vertex] = true;
                        i = 0;
                        boundary[0] = vertex;
                        final_vertex = subgraph_index[subgraph_pointer[vertex] + 1];

                        // determination of the boundary
                        while (reached[final_vertex] == false)
                        {
                            // processing of a saddle with no incident slms_edge
                            if (slms_edge_per_vertex[vertex] == false)
                            {
                                reached[vertex] = true;
                                if (reached[subgraph_index[subgraph_pointer[vertex]]] == false)
                                {
                                    boundary[i + 1] = subgraph_index[subgraph_pointer[vertex]];
                                    vertex = subgraph_index[subgraph_pointer[vertex]];
                                }
                                else
                                {
                                    if (reached[subgraph_index[subgraph_pointer[vertex] + 1]] == false)
                                    {
                                        boundary[i + 1] = subgraph_index[subgraph_pointer[vertex] + 1];
                                        vertex = subgraph_index[subgraph_pointer[vertex] + 1];
                                    }
                                }
                                i++;
                            }
                            else
                            {
                                // processing of a saddle with at least one incident slms_edge  

                                // the first saddle of the slms_edge is processed
                                found_1 = false;
                                reached[vertex] = true;
                                j = subgraph_pointer[vertex];
                                while (j <= subgraph_pointer[vertex + 1] - 1 && found_1 == false)
                                {

                                    if (slms_edge_index[j] > 0)
                                    {
                                        circuit_number = slms_edge_index[j];
                                        slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                        found_1 = true;
                                        vertex_new = subgraph_index[j];
                                    }
                                    else
                                    {
                                        j++;
                                    }

                                }
                                boundary[i + 1] = vertex_new;
                                i++;

                                // the local minimum and the second saddle are processed until all
                                // incident edges of the local minimum have been processed
                                vertex = vertex_new;
                                for (l = 0; l < (subgraph_pointer[vertex + 1] - subgraph_pointer[vertex]) / 2; l++)
                                {
                                    // processing of the local minimum
                                    vertex = vertex_new;
                                    if (l == (subgraph_pointer[vertex + 1] - subgraph_pointer[vertex]) / 2 - 1) reached[vertex] = true;

                                    for (j = subgraph_pointer[vertex]; j <= subgraph_pointer[vertex + 1] - 1; j++)
                                    {
                                        if (slms_edge_index[j] == circuit_number)
                                        {
                                            slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                            if (subgraph_index[j] != boundary[i - 1]) vertex_new = subgraph_index[j];
                                        }
                                    }
                                    boundary[i + 1] = vertex_new;
                                    i++;

                                    // processing of the second saddle point
                                    vertex = vertex_new;
                                    for (j = subgraph_pointer[vertex]; j <= subgraph_pointer[vertex + 1] - 1; j++)
                                    {
                                        if (slms_edge_index[j] == circuit_number)
                                        {
                                            slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                        }
                                        else
                                        {
                                            new_circuit_number = slms_edge_index[j];
                                            slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                            vertex_new = subgraph_index[j];
                                            reached[vertex] = true;
                                        }
                                    }
                                    boundary[i + 1] = vertex_new;
                                    i++;
                                    vertex = vertex_new;
                                    circuit_number = new_circuit_number;
                                }
                            }
                        }
                        boundary_length = i;
                    }

                }

                // the array 'boundary' is modified in such a way that it does no
                // longer store the elements of the array 'subgraph_index', but the
                // elements of the corrresponding array 'subgraph'; this information
                // is passed to the calling procedure
                for (j = 0; j <= boundary_length; j++) boundary[j] = subgraph[boundary[j]];
            }
        }
    

        private static void Manifold_Descending(int m1, int m2, int m3, int[] local_mininimum,
        int[] saddle, int[] local_maximum, int[,] saddle_left, int[,] saddle_right, int lmax,
        int virtual_pit, ref int[,] slms_edges, int number_of_slms_edges, ref int[] boundary, 
        ref int boundary_length, ref int errorcode, ref int[] subgraph, ref int[] subgraph_pointer,
        ref int[] subgraph_index, ref int[] slms_edge_index, ref bool[] slms_edge_per_vertex,
        ref bool[] reached)
        {
            // Parameters
            // m1.......................number of local minima of the critical net
            // m2.......................number of saddle points of the critical net
            // m3.......................number of local maxima of the critical net
            // local_minimum............array storing the names of the local minima; the array
            //                          must be sorted in ascending order
            // saddle...................array storing the names of the saddle points; the array
            //                          must be sorted in ascending order
            // local_maximum............array storing the names of the local maxima; the array
            //                          must be sorted in ascending order
            // saddle_left..............array in which the names of the adjacent local minima
            //                          of the saddle points are stored; it corresponds
            //                          to the subgraph [LMIN,SADD]
            // saddle_right.............array in which the names of the adjacent local maxima
            //                          of the saddle points are stored; it corresponds
            //                          to the subgraph [SADD,LMAX]
            // lmax.....................name of the local maximum from which the boundary of
            //                          the descending manifold D(lmax) must be determined
            // virtual_pit..............name of the local minimum associated with the virtual pit
            // slms_edges...............array storing the slms-edges
            // number_of_slms_edges ....number of slms-edges
            // boundary.................array storing the names of the critical points that
            //                          form the boundary of D(lmax); the first and the last
            //                          element of the array 'boundary' are identical as the
            //                          boundary is closed
            // boundary_length..........number of elements of the array 'boundary'
            // errorcode................specifies the type of error
            // subgraph.................array storing the names of the saddle points and
            //                          local minima which form the boundary of D(lmax); the
            //                          differene to the array 'boundary' is the order in which
            //                          the elements occur
            // subgraph_pointer.........array required for the representation of the subgraph
            //                          by a pointer structure
            // subgraph_index...........array required for the representation of the subgraph  
            //                          by a pointer structure
            // slms_edge_index..........array required for the representation of the slms-edges
            //                          by a pointer structure
            // slms_edge_per_vertex.....array indicating if a specific vertex of the subgraph has
            //                          incident slms-edges
            // reached..................array indicating if a specific vertex of the subgraph has
            //                          aleady been added to the array 'boundary'
            // The (maximal) dimensions of the arrays are as follows:
            // local_minimum[m1], saddle[m2], local_maximum[m3], saddle_left[m2, 2], saddle_right[m2, 2],
            // slms-edges[number_of_slms_edges, 3], boundary[m1 + m2  + 1], subgraph[m1 + m2],
            // subgraph_pointer[m1 + m2 + 1], subgraph_index[2 * (m1 + m2)], slms_edge_index[2 * (m1 + m2)],
            // slms_edge_per_vertex[m1 + m2], reached[m1 + m2]
            // 
            // Errorcode
            // 0. If errorcode = 0, no error was detected
            // 1. If errorcode = 1, m1 < 1 or m2 < 1 or m3 <1 or m1 - m2 + m3 <> 2 was chosen
            // 2. If errorcode = 2, a local minimum was also declared as saddle point or vice versa
            // 3. If errorcode = 3, a local minimum was also declared as local maximum or vice versa
            // 4. If errorcode = 4, a saddle point was also declared as local maximum or vice versa
            // 5. If errorcode = 5, the array 'local_minimum' is not sorted in ascending order
            // 6. If errorcode = 6, the array 'saddle' is not sorted in ascending order
            // 7. If errorcode = 7, the array 'local_maximum' is not sorted in ascending order
            // 8. If errorcode = 8, 'lmax' is not an element of the array 'local_maximum'
            // 9. If errorcode = 9, 'virtual_pit' is not an element of the array 'local_minimum'
            //
            // Remarks
            // 1. The procedure determines the boundary of the descending manifold D(lmax) of the
            //    local maximum 'lmax'. 
            // 2. The region must be surrounded by a virtual pit.
            // 3. The topology of the region must be represented by a critical net.
            // 4. The following two procedures are called:
            //    'Bin_Search' - it determines the position of an element in an array whose
            //                   elements must be different from each other and have to be
            //                   sorted in ascending order.
            //    'Insert'     - it inserts an element into an array, whose elements must
            //                   be different from each other and have to be sorted in
            //                   ascending order, provided the element does not already
            //                   occur in the array; in addition, the procedure modifies the
            //                   number of elements of the array accordingly.

            int i, j, k, l, ifail = 0, ifail_1 = 0, ifail_2 = 0, ifail_3 = 0, pos = 0, pos_0 = 0, pos_1 = 0;
            int circuit_number = 0, new_circuit_number = 0;
            int final_vertex = 0, subgraph_number_of_vertices = 0, vertex, vertex_new = 0;
            bool found_1, found_2, relevant_slms_edge;

            // check for possible input errors
            errorcode = 0;

            if (m1 < 1 || m2 < 1 || m3 < 1 || (m1 - m2 + m3 != 2)) errorcode = 1;

            i = 0;
            while (errorcode == 0 && i <= m1 - 1)
            {
                j = 0;
                while (errorcode == 0 && j <= m2 - 1)
                {
                    if (local_mininimum[i] == saddle[j]) errorcode = 2;
                    j++;
                }
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m1 - 1)
            {
                j = 0;
                while (errorcode == 0 && j <= m3 - 1)
                {
                    if (local_mininimum[i] == local_maximum[j]) errorcode = 3;
                    j++;
                }
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m2 - 1)
            {
                j = 0;
                while (errorcode == 0 && j <= m3 - 1)
                {
                    if (saddle[i] == local_maximum[j]) errorcode = 4;
                    j++;
                }
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m1 - 2)
            {
                if (local_mininimum[i + 1] <= local_mininimum[i]) errorcode = 5;
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m2 - 2)
            {
                if (saddle[i + 1] <= saddle[i]) errorcode = 6;
                i++;
            }

            i = 0;
            while (errorcode == 0 && i <= m3 - 2)
            {
                if (local_maximum[i + 1] <= local_maximum[i]) errorcode = 7;
                i++;
            }

            if (errorcode == 0)
            {
                Bin_Search(local_maximum, m3, lmax, ref pos, ref errorcode);
                if (errorcode > 0) errorcode = 8;
                if (errorcode == 0)
                {
                    Bin_Search(local_mininimum, m1, virtual_pit, ref pos, ref errorcode);
                    if (errorcode > 0) errorcode = 9;
                }
            }

            // no error was detected and the boundary of D(lmax) is determined
            if (errorcode == 0)
            {
                // extraction of the subgraph that contains the boundary of the descending
                // manifold D(lmax), with the result being stored by a pointer structure

                // step one:
                // the array 'subgraph' that contains the names of the saddle points and local
                // minima that form the boundary is built, whereby the elements of the array
                // are sorted in ascending order
                // 'subgraph_number_of_vertices' specifies the number of vertices within the
                // subgraph
                for (i = 0; i <= m2 - 1; i++)
                {
                    if (saddle_right[i, 0] == lmax || saddle_right[i, 1] == lmax)
                    {
                        Insert(ref subgraph, ref subgraph_number_of_vertices, ref saddle[i], ref ifail);
                        Insert(ref subgraph, ref subgraph_number_of_vertices, ref saddle_left[i, 0], ref ifail);
                        Insert(ref subgraph, ref subgraph_number_of_vertices, ref saddle_left[i, 1], ref ifail);
                    }
                }

                // step two:
                // the subgraph is extracted from the array 'saddle_left' and transformed into
                // its undirected form, whereby the result is stored by a pointer structure

                // the array 'subgraph_pointer' is used to identify the sections, in which the
                // adjacent critical points of a vertex are stored 
                // the array 'subgraph_index' specifies the indices of the adjacent vertices
                // as they occur in the array 'subgraph' (all calculations are performed on
                // basis of the array 'subgraph_index')

                // initialisation of the array 'subgraph_pointer'
                for (i = 0; i <= subgraph_number_of_vertices; i++) subgraph_pointer[i] = 0;

                // the pointer structure of the subgraph is built by scanning the saddle
                // points and determining the adjacent local minima
                j = -1;
                for (i = 0; i <= subgraph_number_of_vertices - 1; i++)
                {
                    Bin_Search(saddle, m2, subgraph[i], ref pos, ref ifail);
                    if (ifail == 0)
                    {
                        Bin_Search(subgraph, subgraph_number_of_vertices, saddle_left[pos, 0], ref pos_0, ref ifail);
                        Bin_Search(subgraph, subgraph_number_of_vertices, saddle_left[pos, 1], ref pos_1, ref ifail);
    
                        // the adjacency relationships of the saddle point are modified
                        j = j + 2;
                        for (k = i + 1; k <= subgraph_number_of_vertices; k++) subgraph_pointer[k] = subgraph_pointer[k] + 2;
                        for (k = j - 1; k >= subgraph_pointer[i]; k--) subgraph_index[k + 2] = subgraph_index[k];
                        subgraph_index[subgraph_pointer[i]] = pos_0;
                        subgraph_index[subgraph_pointer[i] + 1] = pos_1;
  
                        // the adjacency relationship of the first local minimum is modified
                        j++;
                        for (k = pos_0 + 1; k <= subgraph_number_of_vertices; k++) subgraph_pointer[k] = subgraph_pointer[k] + 1;
                        for (k = j - 1; k >= subgraph_pointer[pos_0]; k--) subgraph_index[k + 1] = subgraph_index[k];
                        subgraph_index[subgraph_pointer[pos_0]] = i;

                        // the adjacency relationship of the second local minimum is modified
                        j++;
                        for (k = pos_1 + 1; k <= subgraph_number_of_vertices; k++) subgraph_pointer[k] = subgraph_pointer[k] + 1;
                        for (k = j - 1; k >= subgraph_pointer[pos_1]; k--) subgraph_index[k + 1] = subgraph_index[k];
                        subgraph_index[subgraph_pointer[pos_1]] = i;
                    }
                }


                // if slms_edges exist, they are stored in the array 'slms_edge_index', which is built next
                if (number_of_slms_edges > 0)
                {
                    // initialisation of the array 'slms_edge_index'
                    for (i = 0; i <= subgraph_pointer[subgraph_number_of_vertices + 1] - 1; i++) slms_edge_index[i] = 0;
                   
                    for (i = 0; i <= number_of_slms_edges - 1; i++)
                    {
                        Bin_Search(subgraph, subgraph_number_of_vertices, slms_edges[i, 0], ref pos, ref ifail_1);
                        Bin_Search(subgraph, subgraph_number_of_vertices, slms_edges[i, 1], ref pos_0, ref ifail_2);
                        Bin_Search(subgraph, subgraph_number_of_vertices, slms_edges[i, 2], ref pos_1, ref ifail_3);
                        if (ifail_1 == 0 && ifail_2 == 0 && ifail_3 == 0)
                        {
                            // an slms_edge was detected - the first edge is processed
                            found_1 = false;
                            for (j = subgraph_pointer[pos]; j <= subgraph_pointer[pos + 1] - 1; j++)
                            {
                                if (subgraph_index[j] == pos_0 && slms_edge_index[j] == 0 && found_1 == false)
                                {
                                    slms_edge_index[j] = i + 1;
                                    found_1 = true;
                                    found_2 = false;
                                    for (k = subgraph_pointer[pos_0]; k <= subgraph_pointer[pos_0 + 1] - 1; k++)
                                    {
                                        if (subgraph_index[k] == pos && slms_edge_index[k] == 0 && found_2 == false)
                                        {
                                            slms_edge_index[k] = i + 1;
                                            found_2 = true;
                                        }
                                    }
                                }
                            }

                            // an slms_edge was detected - the second edge is processed
                            found_1 = false;
                            for (j = subgraph_pointer[pos_0]; j <= subgraph_pointer[pos_0 + 1] - 1; j++)
                            {
                                if (subgraph_index[j] == pos_1 && slms_edge_index[j] == 0 && found_1 == false)
                                {
                                    slms_edge_index[j] = i + 1;
                                    found_1 = true;
                                    found_2 = false;
                                    for (k = subgraph_pointer[pos_1]; k <= subgraph_pointer[pos_1 + 1] - 1; k++)
                                    {
                                        if (subgraph_index[k] == pos_0 && slms_edge_index[k] == 0 && found_2 == false)
                                        {
                                            slms_edge_index[k] = i + 1;
                                            found_2 = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // the vertices with incident slms_edges are tagged, with the information being
                // stored in the array 'slms_edge_per_vertex'

                // initialisation of the array 'slms_edge_per_vertex'
                for (i = 0; i <= subgraph_number_of_vertices - 1; i++) slms_edge_per_vertex[i] = false;

                for (i = 0; i <= subgraph_number_of_vertices - 1; i++)
                {
                    found_1 = false;
                    j = subgraph_pointer[i];
                    while (j <= subgraph_pointer[i + 1] - 1 && found_1 == false)
                    {
                        if (slms_edge_index[j] > 0)
                        {
                            found_1 = true;
                        }
                        else
                        {
                            j++;
                        }
                    }
                    if (found_1 == true)
                    {
                        slms_edge_per_vertex[i] = true;
                    }
                }

                // if slms-edges, which have to be considered when constructing D(lmax) exist,
                // this information is stored in 'relevant_slms_edge'
                relevant_slms_edge = false;
                i = 0;
                while (i <= subgraph_number_of_vertices - 1 && relevant_slms_edge == false)
                {
                    if (slms_edge_per_vertex[i] == true)
                    {
                        relevant_slms_edge = true;
                    }
                    else
                    {
                        i++;
                    }
                }

                // the circuit corresponding to the boundary of D(lmax) is determined

                // the array 'reached' stores information if a particular vertex of
                // the subgraph has already been added to the boundary or not

                // initialisation of the array 'reached'
                for (i = 0; i <= subgraph_number_of_vertices - 1; i++) reached[i] = false;
 
                if (relevant_slms_edge == false)
                {
                    // there exist no slms_edges in the subgraph
                    reached[0] = true;
                    i = 0;
                    vertex = 0;
                    boundary[0] = 0;
                    while (reached[subgraph_index[1]] == false)
                    {
                        reached[vertex] = true;
                        if (reached[subgraph_index[subgraph_pointer[vertex]]] == false)
                        {
                            boundary[i + 1] = subgraph_index[subgraph_pointer[vertex]];
                            vertex = subgraph_index[subgraph_pointer[vertex]];
                        }
                        else
                        {
                            if (reached[subgraph_index[subgraph_pointer[vertex] + 1]] == false)
                            {
                                boundary[i + 1] = subgraph_index[subgraph_pointer[vertex] + 1];
                                vertex = subgraph_index[subgraph_pointer[vertex] + 1];
                            }
                        }
                        i++;
                    }
                    boundary_length = i;
                }
                else
                {
                    // the subgraph consists of only two vertices, with the edges forming
                    // a circuit
                    if (subgraph_number_of_vertices == 2)
                    {
                        boundary[0] = 0;
                        boundary[1] = 1;
                        boundary[2] = 0;
                        boundary_length = 2;
                    }
                    else
                    // there exists at least one slms_edge in the subgraph
                    {
                        // it is ensured that the boundary always starts in a vertex
                        // with no incident slms-edges
                        vertex = 0;
                        found_1 = false;
                        while (found_1 == false)
                        {
                            if (slms_edge_per_vertex[vertex] == true)
                            {
                                vertex++;
                            }
                            else
                            {
                                found_1 = true;
                            }
                        }
                        
                        // initialisation steps for the determination of the boundary
                        reached[vertex] = true;
                        i = 0;
                        boundary[0] = vertex;
                        final_vertex = subgraph_index[subgraph_pointer[vertex] + 1];

                        // determination of the boundary
                        while (reached[final_vertex] == false)
                        {
                            // processing of a saddle with no incident slms_edge
                            if (slms_edge_per_vertex[vertex] == false)
                            {
                                reached[vertex] = true;
                                if (reached[subgraph_index[subgraph_pointer[vertex]]] == false)
                                {
                                    boundary[i + 1] = subgraph_index[subgraph_pointer[vertex]];
                                    vertex = subgraph_index[subgraph_pointer[vertex]];
                                }
                                else
                                {
                                    if (reached[subgraph_index[subgraph_pointer[vertex] + 1]] == false)
                                    {
                                        boundary[i + 1] = subgraph_index[subgraph_pointer[vertex] + 1];
                                        vertex = subgraph_index[subgraph_pointer[vertex] + 1];
                                    }
                                }
                                i++;
                            }
                            else
                            {
                                // processing of a saddle with at least one incident slms_edge  

                                // the first saddle of the slms_edge is processed
                                found_1 = false;
                                reached[vertex] = true;
                                j = subgraph_pointer[vertex];
                                while (j <= subgraph_pointer[vertex + 1] - 1 && found_1 == false)
                                {

                                    if (slms_edge_index[j] > 0) 
                                    {
                                        circuit_number = slms_edge_index[j];
                                        slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                        found_1 = true;
                                        vertex_new = subgraph_index[j];
                                    }
                                    else
                                    {
                                        j++;
                                    }
                                    
                                }
                                boundary[i + 1] = vertex_new;
                                i++;
                                
                                // the local minimum and the second saddle are processed until all
                                // incident edges of the local minimum have been processed
                                vertex = vertex_new;
                                for (l = 0; l < (subgraph_pointer[vertex + 1] - subgraph_pointer[vertex]) / 2; l++)
                                {
                                    // processing of the local minimum
                                    vertex = vertex_new;
                                    if (l == (subgraph_pointer[vertex + 1] - subgraph_pointer[vertex]) / 2 - 1) reached[vertex] = true;

                                    for (j = subgraph_pointer[vertex]; j <= subgraph_pointer[vertex + 1] - 1; j++)
                                    {
                                        if (slms_edge_index[j] == circuit_number)
                                        {
                                            slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                            if (subgraph_index[j] != boundary[i - 1]) vertex_new = subgraph_index[j];
                                         }
                                    }
                                    boundary[i + 1] = vertex_new;
                                    i++;

                                   // processing of the second saddle point
                                    vertex = vertex_new;
                                    for (j = subgraph_pointer[vertex]; j <= subgraph_pointer[vertex + 1] - 1; j++)
                                    {
                                        if (slms_edge_index[j] == circuit_number)
                                        {
                                            slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                        }
                                        else
                                        {
                                            new_circuit_number = slms_edge_index[j];
                                            slms_edge_index[j] = -Math.Abs(slms_edge_index[j]);
                                            vertex_new = subgraph_index[j];
                                            reached[vertex] = true;
                                        }
                                    }
                                    boundary[i + 1] = vertex_new;
                                    i++;
                                    vertex = vertex_new;
                                    circuit_number = new_circuit_number;
                                }
                            }
                        }
                        boundary_length = i;
                    }

                }

                // the array 'boundary' is modified in such a way that it does no
                // longer store the elements of the array 'subgraph_index', but the
                // elements of the corrresponding array 'subgraph'; this information
                // is passed to the calling procedure
                for (j = 0; j <= boundary_length; j++) boundary[j] = subgraph[boundary[j]];
            }
        }
    }
}

